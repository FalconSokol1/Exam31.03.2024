﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1.DbEnity;
using WpfApp1.Model;
using WpfApp1.View;

namespace WpfApp1.ViewModel
{
    public class AuthVM : BaseVM
    {
        private ObservableCollection<User> _users;
        public ObservableCollection<User> Users
        {
            get => _users;
            set
            {
                _users = value;
                OnPropertyChanged(nameof(Users));
            }
        }

        public ObservableCollection<User> User;


        public UserInfos _userInfos;
        public UserInfos UserInfos
        {
            get { return _userInfos; }
            set
            {
                _userInfos = value;
                OnPropertyChanged("UserInfos");
            }
        }


        //В методе Auth проверяется данные для входа с бд
        public void Auth()
        {
            if(AppData.db.User.Any(u => u.UserLogin == UserInfos.UserLoginn && u.UserPassword == UserInfos.UserPasswordd))
            {
                WorkSpace workSpace = new WorkSpace();
                workSpace.Show();


            }
        }

    }
}
