﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Net.Http.Headers;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using WpfApp1.DbEnity;

namespace WpfApp1.ViewModel
{
    public class WorkSpaceVM : BaseVM
    {
        private Product _selectedProduct;
        private ObservableCollection<Product> _productsInfo;
        public ObservableCollection<Product> Product
        {
            get => _productsInfo;
            set { _productsInfo = value;
                OnPropertyChanged(nameof(Product));

            }
        }

        public Product SelectedProducts
        {
            get => _selectedProduct;
            set
            {
                _selectedProduct = value;
                OnPropertyChanged(nameof(SelectedProducts));
            }
        }
         public void RebindData()
        {
            Product = new ObservableCollection<Product>();
            LoadData();
        }


        public void LoadData()
        {
            var result = AppData.db.Product.ToList();
            result.ForEach(elem => Product?.Add(elem));
            

        }

    }
}
