﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace WpfApp1.Model
{
    public class UserInfos
    {
        public int UserIDd { get; set; }
        public string UserSurnamee { get; set; }
        public string UserNamee { get; set; }
        public string UserPatronymicc { get; set; }
        public string UserLoginn { get; set; }
        public string UserPasswordd { get; set; }
       

    }
}
