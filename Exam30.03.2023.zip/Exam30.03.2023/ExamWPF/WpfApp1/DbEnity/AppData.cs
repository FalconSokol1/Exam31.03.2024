﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.DbEnity
{
    public static class AppData
    {
        public static db3Entities db { get; set; } = new db3Entities();
         
    }
}
